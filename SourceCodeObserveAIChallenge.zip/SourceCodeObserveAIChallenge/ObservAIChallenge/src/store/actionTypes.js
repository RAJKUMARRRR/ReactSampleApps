export const FETCH_POSTS_START = "FETCH_POSTS_START"; 
export const FETCH_POSTS_SUCCESS = "FETCH_POSTS_SUCCESS"; 
export const FETCH_POSTS_FAIL = "FETCH_POSTS_FAIL";


export const POST_CLICK = "POST_CLICK";
export const ADD_POST = "ADD_POST";

export const DELETE_POST = "DELETE_POST";

